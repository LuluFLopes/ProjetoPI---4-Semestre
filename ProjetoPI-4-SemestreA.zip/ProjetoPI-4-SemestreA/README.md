# ProjetoPI-4-Semestre

> Ao clonar o projeto, rodar os seguintes comamndos na dentro da pasta frontend:

```
npm install -g @vue/cli
```

```
vue add vuetify
```

```
npm install axios
```

```
npm install crypto-js
```

```
npm install v-mask
```
