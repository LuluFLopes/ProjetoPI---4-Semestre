package br.com.senacsp.ProjetoPI.enumeracoes.usuario;

public enum Status {
    ATIVO,
    INATIVO;
}
