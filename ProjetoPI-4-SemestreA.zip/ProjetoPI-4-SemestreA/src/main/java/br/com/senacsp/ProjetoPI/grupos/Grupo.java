package br.com.senacsp.ProjetoPI.grupos;

public enum Grupo {
    ADMINISTRADOR,
    ESTOQUISTA;
}
