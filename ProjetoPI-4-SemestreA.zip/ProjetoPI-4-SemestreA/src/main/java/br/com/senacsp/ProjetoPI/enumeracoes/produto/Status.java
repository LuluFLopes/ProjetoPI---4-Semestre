package br.com.senacsp.ProjetoPI.enumeracoes.produto;

public enum Status {
    ATIVO,
    INATIVO;
}
