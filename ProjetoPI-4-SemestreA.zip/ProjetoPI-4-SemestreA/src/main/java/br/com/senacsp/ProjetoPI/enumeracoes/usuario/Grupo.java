package br.com.senacsp.ProjetoPI.enumeracoes.usuario;

public enum Grupo {
    ADMINISTRADOR,
    ESTOQUISTA;
}
