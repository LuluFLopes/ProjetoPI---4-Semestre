package br.com.senacsp.ProjetoPI.enumeracoes.pedidos;

public enum StatusPedido {
    EM_ANDAMENTO,
    CANCELADO,
    CONCLUIDO;
}
