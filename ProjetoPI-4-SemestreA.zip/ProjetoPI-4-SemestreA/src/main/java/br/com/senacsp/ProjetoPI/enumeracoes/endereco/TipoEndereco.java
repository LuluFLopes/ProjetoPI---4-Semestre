package br.com.senacsp.ProjetoPI.enumeracoes.endereco;

public enum TipoEndereco {
    PRINCIPAL,
    SECUNDARIO;
}
