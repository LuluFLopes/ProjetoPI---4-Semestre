package br.com.senacsp.ProjetoPI.grupos;

public enum Status {
    ATIVO,
    INATIVO;
}
