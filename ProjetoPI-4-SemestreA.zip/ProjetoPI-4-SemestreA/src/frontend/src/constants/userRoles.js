export const userRoles = {
  admin: "ADMINISTRADOR",
  stockist: "ESTOQUISTA"
}