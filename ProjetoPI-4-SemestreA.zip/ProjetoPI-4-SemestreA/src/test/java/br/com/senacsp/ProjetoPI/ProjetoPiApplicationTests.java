package br.com.senacsp.ProjetoPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoPiApplicationTests {

	@Test
	void contextLoads() {
	}

}
